create database Student;
use Student;
create table Stu(
sgrade nvarchar(40),
sclass nvarchar(40),
sno nvarchar(40) primary key,
sname nvarchar(40),
Blog nvarchar(40)
);
create table score(
sno nvarchar(40) not null,
bname nvarchar(40) not null,
bscore nvarchar(40),
primary key(sno,bname),
foreign key(sno) references Stu(sno)
)
/*drop database Student;*/
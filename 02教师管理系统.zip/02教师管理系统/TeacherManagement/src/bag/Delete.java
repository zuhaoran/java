package bag;

import java.awt.BorderLayout;
import java.awt.Dimension;
import java.awt.Font;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.awt.event.MouseAdapter;
import java.awt.event.MouseEvent;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.ResultSet;
import java.sql.Statement;
import javax.swing.JButton;
import javax.swing.JFrame;
import javax.swing.JLabel;
import javax.swing.JScrollPane;
import javax.swing.JTable;
import javax.swing.JTextField;

public class Delete 
{
  
	
	public String[] Deletemember4(String sql)
	{
		Connection conn = null;
		Statement stmt = null;
		String Sno[] = null;
		
		try
		{
			Class.forName("com.mysql.jdbc.Driver");
		}
		catch(Exception e)
		{
			System.out.println("��������ʧ�ܡ�");
		}
	
		try
		{
			conn = DriverManager.getConnection("jdbc:mysql://localhost:3306/teachermanagement?user=root&password=MYSQL&characterEncoding=utf8&useSSL=true");
			stmt = conn.createStatement();
		
			int row= stmt.executeUpdate(sql);	
			JFrame J = new JFrame("ɾ���ɹ�");
			JButton but1=new JButton("ȷ��");
			JButton but2=new JButton("����ɾ��");
			J.setLayout(null);
			JLabel L = new JLabel("��Ϣ��ɾ����"+row+"�����ݡ�");
		    but1.setBounds(30, 110,110,30);
		    but1.setFont(new Font("����",Font.BOLD,16));
		    but2.setBounds(170, 110,110,30);
		    but2.setFont(new Font("����",Font.BOLD,16));
			L.setBounds(55, 5, 200,100);
			L.setFont(new Font("����",1,17));
			J.setSize(320, 220);
			J.setLocation(530, 230);
			J.add(L);
			J.add(but1);
			J.add(but2);
			J.setVisible(true);
			but1.addActionListener(new ActionListener()
			{
				public void actionPerformed(ActionEvent arg0)
				{
					if(arg0.getSource()==but1)
					{
						J.setVisible(false);
					}
				}
			});
			but2.addActionListener(new ActionListener()
			{
				public void actionPerformed(ActionEvent arg0)
				{
					if(arg0.getSource()==but2)
					{
						J.setVisible(false);
						Delete1();
					}
				}
			});
		}
		catch(Exception e)
		{
			System.out.println("���ݿ���������쳣��");
		}
	
		try
		{
			stmt.close();
			conn.close();
		}
		catch(Exception e)
		{
			System.out.println("�ر���Դ���̷����쳣��");
		}
		return Sno;
	}
	public String[] Deletemember5(String sql)
	{
		Connection conn = null;
		Statement stmt = null;
		String Sno[] = null;
		
		try
		{
			Class.forName("com.mysql.jdbc.Driver");
		}
		catch(Exception e)
		{
			System.out.println("��������ʧ�ܡ�");
		}
	
		try
		{
			conn = DriverManager.getConnection("jdbc:mysql://localhost:3306/teachermanagement?user=root&password=MYSQL&characterEncoding=utf8&useSSL=true");
			stmt = conn.createStatement();
		
			int row= stmt.executeUpdate(sql);	
			System.out.println(row);
		}
		catch(Exception e)
		{
			System.out.println("���ݿ���������쳣��");
		}
	
		try
		{
			stmt.close();
			conn.close();
		}
		catch(Exception e)
		{
			System.out.println("�ر���Դ���̷����쳣��");
		}
		return Sno;
	}
	public String[] confrimdelete(String sql)
	{
		JFrame J = new JFrame("ȷ��ɾ��");
		JButton but1=new JButton("ȷ��");
		JButton but2=new JButton("ȡ��");
		J.setLayout(null);
		JLabel L = new JLabel("ɾ����Ϣ���");
	    but1.setBounds(30, 110,110,30);
	    but1.setFont(new Font("����",Font.BOLD,16));
	    but2.setBounds(170, 110,110,30);
	    but2.setFont(new Font("����",Font.BOLD,16));
		L.setBounds(55, 5, 200,100);
		L.setFont(new Font("����",1,17));
		J.setSize(320, 220);
		J.setLocation(530, 230);
		but1.addActionListener(new ActionListener()
		{
			public void actionPerformed(ActionEvent arg0)
			{
				if(arg0.getSource()==but1)
				{
					J.setVisible(false);
					Deletemember4(sql);
				}
			}
		});
		but2.addActionListener(new ActionListener()
		{
			public void actionPerformed(ActionEvent arg0)
			{
				if(arg0.getSource()==but2)
				{
					J.setVisible(false);
				}
			}
		});
		J.add(L);
		J.add(but1);
		J.add(but2);
		J.setVisible(true);
		return null;
	}
	public String[] Checkmember4(String sql,String sqldelete)
	{
		
		Connection conn = null;
		Statement stmt = null;
		String Sno[] = null;
		
		try
		{
			Class.forName("com.mysql.jdbc.Driver");
		}
		catch(Exception e)
		{
			System.out.println("��������ʧ�ܡ�");
		}
	
		try
		{
			conn = DriverManager.getConnection("jdbc:mysql://localhost:3306/teachermanagement?user=root&password=MYSQL&characterEncoding=utf8&useSSL=true");
			stmt = conn.createStatement();
			
			int count = 0;
			String[] a1=new String[100];
			String[] a2=new String[100];
			String[] a3=new String[100];
			String[] a4=new String[100];
			String[] a5=new String[100];
			String[] a6=new String[100];
			String[] a7=new String[100];
			String[] a8=new String[100];
			String[] a9=new String[100];
			String[] a10=new String[100];
			String[] a11=new String[100];
			ResultSet rs = null;
			rs = stmt.executeQuery(sql);
			for(int i = 0;i < 100;i++)
			{
				a1[i] = "0";
				a2[i] = "0";
				a3[i] = "0";
				a4[i] = "0";
				a5[i] = "0";
				a6[i] = "0";
				a7[i] = "0";
				a8[i] = "0";
				a9[i] = "0";
				a10[i] = "0";
				a11[i] = "0";
			}
				
			while(rs.next())
			{
				String stid=rs.getString(1);
				String sname=rs.getString(2);
				String  sid= rs.getString(3);
				String saddress=rs.getString(5);
				String sphone=rs.getString(6);
				String sdepartment=rs.getString(7);
				String ssalary=Integer.toString(rs.getInt(8));
				String sworktime=Integer.toString(rs.getInt(9));
				String sprofess=rs.getString(10);
				String sduty=rs.getString(11);
				String sremark=rs.getString(13);
				for(int i = 0;i < 100;i++)
				{
					if(a1[i]==stid)
					{
						break;
					}
					else if(a3[i] != "0")
					{
						continue;
					}
					else
					{
						a1[i] = stid;
						a2[i] =sname;
						a3[i] =sid;
						a4[i] =saddress;
						a5[i] =sphone;
						a6[i] =sdepartment;
						a7[i] =ssalary;
						a8[i] =sworktime;
						a9[i] =sprofess;
						a10[i]=sduty;
						a11[i]=sremark;
						break;
					}
				}
			}
				
			count = 0;
			for(int i = 0;i < 100;i++)
			{
				if(a3[i] != "0")
				{
					count++;
				}
				else
				{
					break;
				}
			}
			count++;
			
			String Snum[] = new String [count];
                 
			for(int i = 0;i < count;i++)
			{
				Snum[i] = a3[i];
			}
			
			String[][] b =new String[count][11];
			for(int i=0;i<count-1;i++)
			{
			  b[i][0]=a1[i];
			  b[i][1]=a2[i];
			  b[i][2]=a3[i];
			  b[i][3]=a4[i];
			  b[i][4]=a5[i];
			  b[i][5]=a6[i];
			  b[i][6]=a7[i];
			  b[i][7]=a8[i];
			  b[i][8]=a9[i];
			  b[i][9]=a10[i];
			  b[i][10]=a11[i];
			}
			if(b[0][0].equals(null))
			{
				JFrame J = new JFrame("������Ϣ");
				JButton but1=new JButton(" �����޸�");
				JButton but2=new JButton("ȡ��");
				J.setLayout(null);
				JLabel L = new JLabel("��ѯ���������");
				but1.setBounds(50, 200,110,40);
		
				but2.setBounds(260, 200,110,40);
		
				L.setBounds(30, -5, 400, 200);
				J.setSize(480, 300);
				J.setLocation(520, 180);
			
				L.setFont(new Font("����",1,15));
				J.add(L);
				J.add(but1);
				J.add(but2);
				but1.addActionListener(new ActionListener(){
					public void actionPerformed(ActionEvent arg0){
						if(arg0.getSource()==but1)
						{
							J.setVisible(false);
						    Delete1();
						}	
					}		
				});
				but2.addActionListener(new ActionListener(){
					public void actionPerformed(ActionEvent arg0){
						if(arg0.getSource()==but2)
						{
							J.setVisible(false);
						}
					}
				});
				J.setVisible(true);
			}
			else
			{
			Object[][] playerInfo = b;
			String[] Names={"��ʦ���","����","����֤��","��ַ","�绰","����","����","����ʱ��","רҵ","ְ��","��ע"};
			JFrame f=new JFrame("��ѯ���");
			f.setBounds(470, 100, 600, 400);
			JTable table=new JTable(playerInfo,Names);
		    table.setPreferredScrollableViewportSize(new Dimension(600,400));
			JScrollPane scrollPane=new JScrollPane(table);
			table.addMouseListener(new MouseAdapter(){
				public void mouseClicked(MouseEvent e){   
					if(e.getClickCount() == 1)
			    	{
						int row =((JTable)e.getSource()).rowAtPoint(e.getPoint()); //�����λ�� 
						String stid=(String)(table.getValueAt(row,0));  
						String sremark=(String)(table.getValueAt(row,10)); 
						
						if(sremark==null)sremark="��";
					    f.setVisible(false);
					    String sqldelete2="delete from teacher where tid='"+stid+"'";
					    Deletemember5(sqldelete2);
						Checkmember4(sql,sqldelete);
			    	}
					else return;
				}
			});
			table.addMouseListener(new MouseAdapter(){
				public void mouseClicked(MouseEvent e){   
					if(e.getClickCount() == 1)
			    	{
					    f.setVisible(false);
			    	}
					else return;
				}
			});
			
			
			f.getContentPane().add(scrollPane,BorderLayout.CENTER);
			f.pack();
			f.setVisible(true);
			confrimdelete(sqldelete);
			}
			
			rs.close();
		}
		catch(Exception e)
		{
			JFrame J = new JFrame("������Ϣ");
			JButton but1=new JButton(" ������ѯ");
			JButton but2=new JButton("ȡ��");
			J.setLayout(null);
			JLabel L = new JLabel("��ѯ���������");
			but1.setBounds(50, 200,110,40);
	
			but2.setBounds(260, 200,110,40);
	
			L.setBounds(30, -5, 400, 200);
			J.setSize(480, 300);
			J.setLocation(520, 180);
		
			L.setFont(new Font("����",1,15));
			J.add(L);
			J.add(but1);
			J.add(but2);
			but1.addActionListener(new ActionListener(){
				public void actionPerformed(ActionEvent arg0){
					if(arg0.getSource()==but1)
					{
						J.setVisible(false);
						Delete1();
					}	
				}		
			});
			but2.addActionListener(new ActionListener(){
				public void actionPerformed(ActionEvent arg0){
					if(arg0.getSource()==but2)
					{
						J.setVisible(false);
					}
				}
			});
			J.setVisible(true);
		}
	
		try
		{
			stmt.close();
			conn.close();
		}
		catch(Exception e)
		{
			System.out.println("�ر���Դ���̷����쳣��");
		}
		return Sno;
	}

	

	public void Delete1()
	{
		Font f1=new Font("����",Font.BOLD,19);
		Font f2=new Font("����",Font.BOLD,16);
		
		JFrame frame =new JFrame("��ѯ��ʽѡ��");
		frame.setLayout(null);;
		JLabel ltid= new JLabel("��ʦ���");
		JLabel lname= new JLabel("��ʦ����");
		JLabel lbrithday= new JLabel("�������·�Χ");
		JLabel lbrithday2= new JLabel("��");
		JLabel lsalary= new JLabel("���ʷ�Χ");
		JLabel lsalary2= new JLabel("��");
		JLabel lworktime= new JLabel("�� �ӹ���ʱ�䷶Χ");
		JTextField ttid=new JTextField(30);
		JTextField tname=new JTextField(30);
		JTextField tbrithday=new JTextField(30);
		JTextField tbrithday2=new JTextField(30);
		JTextField tsalary=new JTextField(30);
		JTextField tsalary2=new JTextField(30);
		JTextField tworktime=new JTextField(30);
		JButton all= new JButton("ȫ����Ϣ");
		JButton confirm= new JButton("ȷ��");
		JButton ret= new JButton("����");
		
		ltid.setBounds(10, 50, 100, 30);
		lname.setBounds(10, 130, 100, 30);
		lbrithday.setBounds(10, 210, 100, 30);
		lsalary.setBounds(10, 290, 100, 30);
		lbrithday2.setBounds(230, 210, 100, 30);
		lsalary2.setBounds(230, 290, 100, 30);
		lworktime.setBounds(10, 370, 100, 30);
		
		
		ttid.setBounds(120, 50, 100, 30);
		tname.setBounds(120, 130, 100, 30);
		tbrithday.setBounds(120, 210, 100, 30);
		tsalary.setBounds(120, 290, 100, 30);
		tbrithday2.setBounds(270, 210, 100, 30);
		tsalary2.setBounds(270, 290, 100, 30);
		tworktime.setBounds(120,370, 100, 30);
		
		
		all.setBounds(10, 450, 100, 30);
		confirm.setBounds(140, 450, 100, 30);
		ret.setBounds(260, 450, 100, 30);
		
		all.addActionListener(new ActionListener(){
        	public void actionPerformed(ActionEvent arg0){
        		if(arg0.getSource()==all)
        		{
        			String sql="select * from teacher";
        			String sqldelete="delete from teacher";
        			Checkmember4(sql,sqldelete);
        			frame.setVisible(false);
        		} 
        	}
        });
		confirm.addActionListener(new ActionListener(){
        	public void actionPerformed(ActionEvent arg0){
        		if(arg0.getSource()==confirm)
        		{
        			String  false0 = "",false1 = "",false2 = "",false3 = "",false4 = "",false5 = "",false6 = "",falseZ = "";
        			if(ttid.getText().equals("")&&tname.getText().equals("")&&tbrithday.getText().equals("")&&tsalary.getText().equals("")&&tbrithday2.getText().equals("")&&tsalary2.getText().equals("")&&tworktime.getText().equals(""))
					{
        				
	        			JFrame J = new JFrame("������Ϣ");
						JButton but1=new JButton("��������");
						JButton but2=new JButton("ȡ��");
						J.setLayout(null);
						JLabel L = new JLabel("����ֵ����ȫΪ��");
						but1.setBounds(50, 200,110,40);
						but1.setFont(f2);
						but2.setBounds(260, 200,110,40);
						but2.setFont(f2);
						L.setBounds(30, -5, 400, 200);
						J.setSize(480, 300);
						J.setLocation(520, 180);
						J.setFont(f1);
						L.setFont(new Font("����",1,15));
						J.add(L);
						J.add(but1);
						J.add(but2);
						but1.addActionListener(new ActionListener(){
							public void actionPerformed(ActionEvent arg0){
								if(arg0.getSource()==but1)
								{
									J.setVisible(false);
									frame.setVisible(true);
								}	
							}		
						});
						but2.addActionListener(new ActionListener(){
							public void actionPerformed(ActionEvent arg0){
								if(arg0.getSource()==but2)
								{
									J.setVisible(false);
									frame.setVisible(false);
								}
							}
						});
						J.setVisible(true);
					}
					else
					{
						if(!ttid.getText().equals(""))
						{
							false0 = " and tid = '"+ttid.getText()+"' ";
							falseZ += false0;
						}
						if(!tname.getText().equals(""))
						{
							false1 = " and name= '"+tname.getText()+"' ";
							falseZ += false1;
						}
						if(!tbrithday.getText().equals(""))
						{
							false2 = " and brithday >= "+ Integer.parseInt(tbrithday.getText());
							falseZ += false2;
						}
						if(!tbrithday2.getText().equals(""))
						{
							false3 = " and brithday <= "+ Integer.parseInt(tbrithday2.getText());
							falseZ += false3;
						}
						if(!tsalary.getText().equals(""))
						{
							false4 = " and salary >= "+ Integer.parseInt(tsalary.getText());
							falseZ += false4;
						}	
						if(!tsalary2.getText().equals(""))
						{
							false5 = " and salary <= "+ Integer.parseInt(tsalary.getText());
							falseZ += false5;
						}
						if(!tworktime.getText().equals(""))
						{
							false6 =  " and worktime = "+ Integer.parseInt(tworktime.getText());
							falseZ += false6;
						}
						String sqlcheck="select * from teacher where inoffice='yes' "+falseZ;
						String sqldelete="delete from teacher where inoffice='yes' "+falseZ;
	        			Checkmember4(sqlcheck,sqldelete);
					}
        			frame.setVisible(false);
        		}
        	}
        });
		ret.addActionListener(new ActionListener(){
        	public void actionPerformed(ActionEvent arg0){
        		if(arg0.getSource()==ret)
        		{
        		
        			frame.setVisible(false);
        		} 
        	}
        });
		frame.setSize(420, 520);
		frame.setLocation(530, 130);
		frame.add(ltid);
		frame.add(lname);
		frame.add(lbrithday);
		frame.add(lsalary);
		frame.add(lbrithday2);
		frame.add(lsalary2);
		frame.add(lworktime);
		frame.add(ttid);
		frame.add(tname);
		frame.add(tbrithday);
		frame.add(tsalary);
		frame.add(tbrithday2);
		frame.add(tsalary2);
		frame.add(tworktime);
		frame.add(all);
		frame.add(confirm);
		frame.add(ret);
		frame.setVisible(true);
	}
	
	public  Delete()
	{
		JFrame frame =new JFrame("ɾ��ȷ��");
		frame.setLayout(null);
		JLabel Label= new JLabel("�Ƿ�Ҫ���н�ʦ��Ϣɾ��");
		JButton but1= new JButton("��");
		JButton but2= new JButton("��");
		
		Font f1=new Font("����",Font.BOLD,17);
		Font f2=new Font("����",Font.BOLD,15);
		
	    but1.setBounds(40, 110,90,30);
	    but1.setFont(f2);
	    but2.setBounds(160, 110,90,30);
	    but2.setFont(f2);
		Label.setBounds(50, 5, 200,100);
		Label.setFont(f1);
		frame.setSize(320, 220);
		frame.setLocation(530, 230);
		
		 but1.addActionListener(new ActionListener(){
				public void actionPerformed(ActionEvent arg0){
					if(arg0.getSource()==but1)
					{
						Delete1();
						frame.setVisible(false);
					}
				}
			});
		 but2.addActionListener(new ActionListener(){
				public void actionPerformed(ActionEvent arg0){
					if(arg0.getSource()==but2)
					{
						frame.setVisible(false);
					}
				}
			}); 
		 
		 frame.add(Label);
		 frame.add(but1);
		 frame.add(but2);
		 frame.setVisible(true);
		 
		 
	}
}
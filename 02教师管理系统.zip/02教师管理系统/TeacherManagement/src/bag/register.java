package bag;

import java.awt.Font;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.awt.event.ItemEvent;
import java.awt.event.ItemListener;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.ResultSet;
import java.sql.Statement;
import javax.swing.JButton;
import javax.swing.JComboBox;
import javax.swing.JFrame;
import javax.swing.JLabel;
import javax.swing.JTextField;

public class register {
	String spower;
	Boolean pan;
   public register()
   {

		Font f1=new Font("����",Font.BOLD,19);
		Font f2=new Font("����",Font.BOLD,16);
	   JFrame frame =new JFrame();
	   frame.setLayout(null);
	   JLabel laccount=new JLabel("�˺�");
	   JLabel lpassword=new JLabel("����");
	   JLabel lpower=new JLabel("����");
	   JTextField taccount=new JTextField(30);
	   JTextField tpassword= new JTextField(30);
	   JButton confirm=new JButton("ȷ��");
	   JButton reset=new JButton("ȡ��");
	   String[] v={"����Ա","��ͨ�û�"};
	   spower="����Ա";
	   JComboBox power=new JComboBox(v);
	   power.addItemListener(new ItemListener(){
			public void itemStateChanged(ItemEvent e){
	        	if(e.getStateChange()==ItemEvent.SELECTED)
	        	{
	        		String item=(String)e.getItem();
	        		
	        		spower=item;
	        	}
	    	}
		});
	   confirm.addActionListener(new ActionListener(){
		   public void actionPerformed(ActionEvent arg0){
			   if(arg0.getSource()==confirm)
			   {
				   frame.setVisible(false);
				   String  false0 = "",false1 = "",falseZ = "";
					if(taccount.getText().equals("")||tpassword.getText().equals(""))
					{
						if(taccount.getText().equals(""))
						{
							false0 = "�˺�";
							falseZ += false0+"��";
						}
						if(tpassword.getText().equals(""))
						{
							false1 = "����";
							falseZ += false1+"��";
						}	
						JFrame J = new JFrame("������Ϣ");
						JButton but1=new JButton("��������");
						JButton but2=new JButton("ȡ��");
						J.setLayout(null);
						JLabel L = new JLabel(falseZ+"��������ֵ����Ϊ��");
						but1.setBounds(50, 200,110,40);
						but1.setFont(f2);
						but2.setBounds(260, 200,110,40);
						but2.setFont(f2);
						L.setBounds(30, -5, 400, 200);
						J.setSize(480, 300);
						J.setLocation(520, 180);
						J.setFont(f1);
						L.setFont(new Font("����",1,15));
						J.add(L);
						J.add(but1);
						J.add(but2);
						J.setVisible(true);
						
						but1.addActionListener(new ActionListener(){
							public void actionPerformed(ActionEvent arg0){
								if(arg0.getSource()==but1)
								{
									J.setVisible(false);
									frame.setVisible(true);
								}	
							}		
						});
						but2.addActionListener(new ActionListener(){
							public void actionPerformed(ActionEvent arg0){
								if(arg0.getSource()==but2)
								{
									J.setVisible(false);
									frame.setVisible(false);
								}
							}
						});
					}
					else
					{
						String account =taccount.getText();
						frame.setVisible(false);
						Connection conn = null;
						Statement stmt = null;
						
						try
						{
							Class.forName("con.mysql.jdbc.Driver");
						}
						catch(Exception e)
						{
							JFrame J = new JFrame();
							JLabel L = new JLabel("��������ʧ�ܡ�");
							J.add(L);
						}
						pan=false;
						try
						{   
							String ssql="select account from teacheraccount ";
							conn = DriverManager.getConnection("jdbc:mysql://localhost:3306/teachermanagement?user=root&password=MYSQL&characterEncoding=utf8&useSSL=true");
							stmt = conn.createStatement();
							ResultSet rs = null;
							rs = stmt.executeQuery(ssql);
							
							while(rs.next())
							{
								String saccount=rs.getString(1);
								if (saccount.equals(account)) pan=true;
							}
							
						}
						catch(Exception e)
						{
							pan=false;
						}
						if(pan==false)
						{
							try
							{
								conn = DriverManager.getConnection("jdbc:mysql://localhost:3306/teachermanagement?user=root&password=MYSQL&characterEncoding=utf8&useSSL=true");
								stmt = conn.createStatement();
								String Saccount = taccount.getText();
								String Spassword = tpassword.getText();
								String sql = "Insert into teacheraccount values('"+Saccount+"','"+Spassword+"','"+spower+"')";
								int row = stmt.executeUpdate(sql);
								JFrame J = new JFrame("���ӳɹ�");
								
								JButton but1=new JButton("ȷ��");
								J.setLayout(null);
								JLabel L = new JLabel("ע��ɹ�");
							    but1.setBounds(30, 110,110,30);
							    but1.setFont(f2);
								L.setBounds(55, 5, 200,100);
								L.setFont(new Font("����",1,17));
								J.setSize(320, 220);
								J.setLocation(530, 230);
								J.add(L);
								J.add(but1);
								J.setVisible(true);
								but1.addActionListener(new ActionListener()
								{
									public void actionPerformed(ActionEvent arg0)
									{
										if(arg0.getSource()==but1)
										{
											frame.setVisible(false);
											J.setVisible(false);
										}
									}
								});
							}
							catch(Exception e)
							{
								JFrame J = new JFrame();
								JLabel L = new JLabel("���ݿ�������̷������쳣��");
								J.add(L);
							}
						}
						else
							{
							JFrame J = new JFrame("ע��ʧ��");
							
							JButton but1=new JButton("ȷ��");
							J.setLayout(null);
							JLabel L = new JLabel("�û����Ѵ���");
						    but1.setBounds(30, 110,110,30);
						    but1.setFont(f2);
							L.setBounds(55, 5, 200,100);
							L.setFont(new Font("����",1,17));
							J.setSize(320, 220);
							J.setLocation(530, 230);
							J.add(L);
							J.add(but1);
							J.setVisible(true);
							but1.addActionListener(new ActionListener()
							{
								public void actionPerformed(ActionEvent arg0)
								{
									if(arg0.getSource()==but1)
									{
										J.setVisible(false);
									}
								}
							});

							}
						try
						{
							stmt.close();
							conn.close();
						}
						catch(Exception e)
						{
							JFrame J = new JFrame();
							JLabel L = new JLabel("�ر����ݿ����ӷ����쳣��");
							J.add(L);
						}
					}
				
				}
		   }
	   });
	   reset.addActionListener(new ActionListener(){
		   public void actionPerformed(ActionEvent arg0){
			   if(arg0.getSource()==reset)
			   {
				   frame.setVisible(false);
			   }
		   }
	   });
	   
	   frame.setBounds(500, 200, 400, 300);
	   laccount.setBounds(20,10,50,30);
	   lpassword.setBounds(20,70,50,30);
	   taccount.setBounds(80, 10, 150, 30);
	   tpassword.setBounds(80, 70, 150, 30);
	   lpower.setBounds(20, 120, 150, 30);
	   power.setBounds(80,120 , 150, 50);
	   confirm.setBounds(30,190,80,30);
	   reset.setBounds(120, 190, 80, 30);
	   frame.add(laccount);
	   frame.add(taccount);
	   frame.add(lpassword);
	   frame.add(tpassword);
	   frame.add(lpower);
	   frame.add(power);
	   frame.add(confirm);
	   frame.add(reset);
	   frame.setVisible(true);
   }
   
}

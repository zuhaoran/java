package bag;

import java.awt.BorderLayout;
import java.awt.Dimension;
import java.awt.Font;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.awt.event.MouseAdapter;
import java.awt.event.MouseEvent;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.ResultSet;
import java.sql.Statement;
import javax.swing.JButton;
import javax.swing.JFrame;
import javax.swing.JLabel;
import javax.swing.JScrollPane;
import javax.swing.JTable;
import javax.swing.JTextField;

public class Change
{
	public void Changedelete(String sqlword,String stid,String sname,String sid,String saddress,String sphone,String sdepartment,String ssalary,String sworktime,String sprofess,String sduty,String sremark)
	{
		try
		{
			Font f1=new Font("����",Font.BOLD,19);
			Font f2=new Font("����",Font.BOLD,16);
			
			JFrame frame =new JFrame("������Ҫ�޸ĵĽ�ʦ��Ϣ");
			JLabel t0 =new JLabel("���");
			JLabel t1 =new JLabel("����");
			JLabel t2 =new JLabel("����֤��");
			JLabel t3 =new JLabel("��ַ");
			JLabel t4 =new JLabel("�绰");
			JLabel t5 =new JLabel("����");
			JLabel t6 =new JLabel("����");
			JLabel t7 =new JLabel("�μӹ���ʱ��");
			JLabel t71 =new JLabel("��");
			JLabel t8 =new JLabel("רҵ");
			JLabel t9 =new JLabel("ְ��");
			JLabel t10 =new JLabel("��ע");
			JTextField tid=new JTextField(stid,30);
			t10.setFocusable(false);
			JTextField name=new JTextField(sname,30);
			JTextField id=new JTextField(sid,30);
			JTextField address=new JTextField(saddress,30);
			JTextField phone=new JTextField(sphone,30);
			JTextField department=new JTextField(sdepartment,50);
			JTextField salary=new JTextField(ssalary,50);
			JTextField worktime=new JTextField(sworktime,50);
			JTextField profess=new JTextField(sprofess,50);
			JTextField duty=new JTextField(sduty,50);
			JTextField remark=new JTextField(sremark,50);
			
			JButton breset =new JButton("����");
			JButton bchange =new JButton("����");
			JButton breturn =new JButton("ȡ��");
			frame.setLayout(null);
			t0.setBounds(100, 0, 90, 50);
			t0.setFont(f2);
			t1.setBounds(100, 50, 90, 50);
			t1.setFont(f2);
			t2.setBounds(70, 100, 90, 50);
			t2.setFont(f2);
			t3.setBounds(100, 150, 90, 50);
			t3.setFont(f2);
			t4.setBounds(100, 200, 90, 50);
			t4.setFont(f2);
			t5.setBounds(100, 250, 90, 50);
			t5.setFont(f2);
			t6.setBounds(100, 300, 90, 50);
			t6.setFont(f2);
			t7.setBounds(30, 350, 130, 50);
			t7.setFont(f2);
			t71.setBounds(400, 350, 130, 50);
			t7.setFont(f2);
			t8.setBounds(100, 400, 90, 50);
			t8.setFont(f2);
			t9.setBounds(100, 450, 90, 50);
			t9.setFont(f2);
			t10.setBounds(100, 500, 90, 50);
			t10.setFont(f2);
			tid.setBounds(150, 10, 250, 30);
			name.setBounds(150, 60, 250, 30);
			id.setBounds(150, 110, 250, 30);
			address.setBounds(150, 160, 250, 30);
			phone.setBounds(150, 210,250, 30);
			department.setBounds(150, 260, 250, 30);
			salary.setBounds(150, 310, 250, 30);
			worktime.setBounds(150, 360, 250, 30);
			profess.setBounds(150, 410, 250, 30);
			duty.setBounds(150, 460, 250, 30);
			remark.setBounds(150, 510, 250, 30);
			breset.setBounds(60, 560, 80, 30);
		    breset.setFont(f2);
			bchange.setBounds(200, 560,  80, 30);
			bchange.setFont(f2);
			breturn.setBounds(350, 560,  80, 30);
			breturn.setFont(f2);
			frame.add(t0);
			frame.add(tid);
			frame.add(t1);
			frame.add(name);
			frame.add(t2);
			frame.add(id);
			frame.add(t3);
			frame.add(address);
			frame.add(t4);
			frame.add(phone);
			frame.add(t5);
			frame.add(department);
			frame.add(t6);
			frame.add(salary);
			frame.add(t7);
			frame.add(t71);
			frame.add(worktime);
			
			frame.add(t8);
			frame.add(profess);
			frame.add(t9);
			frame.add(duty);
			frame.add(t10);
			frame.add(remark);
			frame.add(breset);
			frame.add(bchange);
			frame.add(breturn);
			frame.setLocation(500, 110);
			frame.setSize(500, 650);
			frame.setVisible(true);
			
	
			breset.addActionListener(new ActionListener(){
				public void actionPerformed(ActionEvent arg0){
					if(arg0.getSource()==breset)
					{
						frame.setVisible(false);
					 Changedelete( sqlword, stid, sname,sid, saddress, sphone, sdepartment,ssalary, sworktime, sprofess, sduty, sremark);
						
					}
				}
			});
			bchange.addActionListener(new ActionListener(){
				public void actionPerformed(ActionEvent arg0){
					if(arg0.getSource()==bchange)
					{
						frame.setVisible(false);
						String  false0 = "",false1 = "",false2 = "",false3 = "",false4 = "",false5 = "",false6 = "",false7= "",false8 = "",false9 = "",falseZ = "";
						if(tid.getText().equals("")||name.getText().equals("")||id.getText().equals("")||address.getText().equals("")
						  ||phone.getText().equals("")||department.getText().equals("")||salary.getText().equals("")||worktime.getText().equals("")
						  ||profess.getText().equals("")||duty.getText().equals("")||id.getText().length()!=18)
						{
							if(tid.getText().equals(""))
							{
								false0 = "��ʦ���";
								falseZ += false0+"��";
							}
							if(name.getText().equals(""))
							{
								false1 = "����";
								falseZ += false1+"��";
							}
							if(id.getText().equals("")||id.getText().length()!=18)
							{
								false2 = "����֤��";
								falseZ += false2+"��";
							}
							if(address.getText().equals(""))
							{
								false3 = "��ַ";
								falseZ += false3+"��";
							}
							if(phone.getText().equals(""))
							{
								false4 = "�ֻ���";
								falseZ += false4+"��";
							}	
							if(department.getText().equals(""))
							{
								false5 = "����";
								falseZ += false5;
							}
							if(salary.getText().equals(""))
							{
								false6 = "����";
								falseZ += false6;
							}
							if(worktime.getText().equals(""))
							{
								false7 = "�μӹ���ʱ��";
								falseZ += false7;
							}
							if(profess.getText().equals(""))
							{
								false8 = "ְ��";
								falseZ += false8;
							}
							if(duty.getText().equals(""))
							{
								false9 = "רҵ";
								falseZ += false9;
							}
				
							
							JFrame J = new JFrame("������Ϣ");
							JButton but1=new JButton("��������");
							JButton but2=new JButton("ȡ��");
							J.setLayout(null);
							JLabel L = new JLabel(falseZ+"��������ֵ����Ϊ�ջ򲻷���Ҫ��");
							but1.setBounds(50, 200,110,40);
							but1.setFont(f2);
							but2.setBounds(260, 200,110,40);
							but2.setFont(f2);
							L.setBounds(30, -5, 400, 200);
							J.setSize(480, 300);
							J.setLocation(520, 180);
							J.setFont(f1);
							L.setFont(new Font("����",1,15));
							J.add(L);
							J.add(but1);
							J.add(but2);
							J.setVisible(true);
							
							but1.addActionListener(new ActionListener(){
								public void actionPerformed(ActionEvent arg0){
									if(arg0.getSource()==but1)
									{
										J.setVisible(false);
										frame.setVisible(true);
									
									}	
								}		
							});
							but2.addActionListener(new ActionListener(){
								public void actionPerformed(ActionEvent arg0){
									if(arg0.getSource()==but2)
									{
										J.setVisible(false);
										frame.setVisible(false);
									}
								}
							});
						}
						else
						{
							frame.setVisible(false);
							Connection conn = null;
							Statement stmt = null;
							
							try
							{
								Class.forName("con.mysql.jdbc.Driver");
							}
							catch(Exception e)
							{
								JFrame J = new JFrame();
								JLabel L = new JLabel("��������ʧ�ܡ�");
								J.add(L);
							}
							
							try
							{
								conn = DriverManager.getConnection("jdbc:mysql://localhost:3306/teachermanagement?user=root&password=MYSQL&characterEncoding=utf8&useSSL=true");
								stmt = conn.createStatement();
								String Stid = tid.getText();
								String Sname = name.getText();
								String Sid = id.getText();
								String Sbrithday=Sid.substring(7,15);
								int ibrithday=Integer.parseInt(Sbrithday);
								String saddress = address.getText();
								String sphone = phone.getText();
								String sdepartment = department.getText();
								int isalary = Integer.parseInt(salary.getText());
								String sworktime = worktime.getText();
								int iworktime=Integer.parseInt(sworktime);
								String sprofess = profess.getText();
								String sduty = duty.getText();
								String sremark="��";
								if((remark.getText().equals("")))
								{
									 sremark="��";
								}
								else
								{	
									 sremark = remark.getText();
								}
								String sql = "update teacher set name='"+Sname+"' , id='"+Sid+"' , brithday="+ibrithday+" , address='"+saddress+"' , phone='"+sphone+"' , department='"+sdepartment+"' , salary="+isalary+" , worktime="+iworktime+" , profess='"+sprofess+"' , duty='"+sduty+"' , inoffice='yes' , remark='"+sremark+"' where  tid='"+Stid+"'";
								int row = stmt.executeUpdate(sql);
								JFrame J = new JFrame("���ĳɹ�");
								
								JButton but1=new JButton("ȷ��");
								J.setLayout(null);
								JLabel L = new JLabel("��Ϣ��������"+row+"������");
							    but1.setBounds(30, 110,110,30);
							    but1.setFont(f2);
								L.setBounds(55, 5, 200,100);
								L.setFont(new Font("����",1,17));
								J.setSize(320, 220);
								J.setLocation(530, 230);
								J.add(L);
								J.add(but1);
								J.setVisible(true);
								but1.addActionListener(new ActionListener()
								{
									public void actionPerformed(ActionEvent arg0)
									{
										if(arg0.getSource()==but1)
										{
											frame.setVisible(false);
											J.setVisible(false);
											Changemember4( sqlword);
										}
									}
								});
								
							}
							catch(Exception e)
							{
								JFrame J = new JFrame();
								JLabel L = new JLabel("���ݿ�������̷������쳣��");
								J.add(L);
							}
							
							try
							{
								stmt.close();
								conn.close();
							}
							catch(Exception e)
							{
								JFrame J = new JFrame();
								JLabel L = new JLabel("�ر����ݿ����ӷ����쳣��");
								J.add(L);
							}
						}
					}
				}
			});
			breturn.addActionListener(new ActionListener(){
				public void actionPerformed(ActionEvent arg0){
					if(arg0.getSource()==breturn)
					{
						frame.setVisible(false);
					}
				}
			});
		}
		catch(Exception e)
		{
			System.out.println(" ���ݿ�����쳣");
		}
	}
	public String[] Changemember4(String sql)
	{
		
		Connection conn = null;
		Statement stmt = null;
		String Sno[] = null;
		
		try
		{
			Class.forName("com.mysql.jdbc.Driver");
		}
		catch(Exception e)
		{
			System.out.println("��������ʧ�ܡ�");
		}
	
		try
		{
			conn = DriverManager.getConnection("jdbc:mysql://localhost:3306/teachermanagement?user=root&password=MYSQL&characterEncoding=utf8&useSSL=true");
			stmt = conn.createStatement();
			
			int count = 0;
			String[] a1=new String[100];
			String[] a2=new String[100];
			String[] a3=new String[100];
			String[] a4=new String[100];
			String[] a5=new String[100];
			String[] a6=new String[100];
			String[] a7=new String[100];
			String[] a8=new String[100];
			String[] a9=new String[100];
			String[] a10=new String[100];
			String[] a11=new String[100];
			ResultSet rs = null;
			rs = stmt.executeQuery(sql);
			for(int i = 0;i < 100;i++)
			{
				a1[i] = "0";
				a2[i] = "0";
				a3[i] = "0";
				a4[i] = "0";
				a5[i] = "0";
				a6[i] = "0";
				a7[i] = "0";
				a8[i] = "0";
				a9[i] = "0";
				a10[i] = "0";
				a11[i] = "0";
			}
				
			while(rs.next())
			{
				String stid=rs.getString(1);
				String sname=rs.getString(2);
				String  sid= rs.getString(3);
				String saddress=rs.getString(5);
				String sphone=rs.getString(6);
				String sdepartment=rs.getString(7);
				String ssalary=Integer.toString(rs.getInt(8));
				String sworktime=Integer.toString(rs.getInt(9));
				String sprofess=rs.getString(10);
				String sduty=rs.getString(11);
				String sremark=rs.getString(13);
				for(int i = 0;i < 100;i++)
				{
					if(a1[i]==stid)
					{
						break;
					}
					else if(a3[i] != "0")
					{
						continue;
					}
					else
					{
						a1[i] = stid;
						a2[i] =sname;
						a3[i] =sid;
						a4[i] =saddress;
						a5[i] =sphone;
						a6[i] =sdepartment;
						a7[i] =ssalary;
						a8[i] =sworktime;
						a9[i] =sprofess;
						a10[i]=sduty;
						a11[i]=sremark;
						break;
					}
				}
			}
				
			count = 0;
			for(int i = 0;i < 100;i++)
			{
				if(a3[i] != "0")
				{
					count++;
				}
				else
				{
					break;
				}
			}
			count++;
			
			String Snum[] = new String [count];
                 
			for(int i = 0;i < count;i++)
			{
				Snum[i] = a3[i];
			}
			
			String[][] b =new String[count][11];
			for(int i=0;i<count-1;i++)
			{
			  b[i][0]=a1[i];
			  b[i][1]=a2[i];
			  b[i][2]=a3[i];
			  b[i][3]=a4[i];
			  b[i][4]=a5[i];
			  b[i][5]=a6[i];
			  b[i][6]=a7[i];
			  b[i][7]=a8[i];
			  b[i][8]=a9[i];
			  b[i][9]=a10[i];
			  b[i][10]=a11[i];
			}
			if(b[0][0].equals(null))
			{
				JFrame J = new JFrame("������Ϣ");
				JButton but1=new JButton(" �����޸�");
				JButton but2=new JButton("ȡ��");
				J.setLayout(null);
				JLabel L = new JLabel("��ѯ���������");
				but1.setBounds(50, 200,110,40);
		
				but2.setBounds(260, 200,110,40);
		
				L.setBounds(30, -5, 400, 200);
				J.setSize(480, 300);
				J.setLocation(520, 180);
			
				L.setFont(new Font("����",1,15));
				J.add(L);
				J.add(but1);
				J.add(but2);
				but1.addActionListener(new ActionListener(){
					public void actionPerformed(ActionEvent arg0){
						if(arg0.getSource()==but1)
						{
							J.setVisible(false);
							 Change1();
						}	
					}		
				});
				but2.addActionListener(new ActionListener(){
					public void actionPerformed(ActionEvent arg0){
						if(arg0.getSource()==but2)
						{
							J.setVisible(false);
						}
					}
				});
				J.setVisible(true);
			}
			else
			{
			Object[][] playerInfo = b;
			String[] Names={"��ʦ���","����","����֤��","��ַ","�绰","����","����","����ʱ��","רҵ","ְ��","��ע"};
			JFrame f=new JFrame("��ѯ���");
			f.setBounds(470, 100, 600, 400);
			JTable table=new JTable(playerInfo,Names);
		    table.setPreferredScrollableViewportSize(new Dimension(600,400));
			JScrollPane scrollPane=new JScrollPane(table);
			
			table.addMouseListener(new MouseAdapter(){
				public void mouseClicked(MouseEvent e){   
					if(e.getClickCount() == 1)
			    	{
						int row =((JTable)e.getSource()).rowAtPoint(e.getPoint()); //�����λ�� 
						String stid=(String)(table.getValueAt(row,0)); 
						String sname=(String)(table.getValueAt(row,1)); 
						String sid=(String)(table.getValueAt(row,2)); 
						String saddress=(String)(table.getValueAt(row,3)); 
						String sphone=(String)(table.getValueAt(row,4)); 
						String sdepartment=(String)(table.getValueAt(row,5)); 
						String ssalary=(String)(table.getValueAt(row,6)); 
						String sworktime=(String)(table.getValueAt(row,7)); 
						String sprofess=(String)(table.getValueAt(row,8)); 
						String sduty=(String)(table.getValueAt(row,9)); 
						String sremark=(String)(table.getValueAt(row,10)); 
						
						if(sremark==null)sremark="��";
					    f.setVisible(false);
						Changedelete(sql,stid,sname,sid,saddress,sphone,sdepartment,ssalary,sworktime,sprofess,sduty,sremark);
			    	}
					else return;
				}
			});
			
			
			f.getContentPane().add(scrollPane,BorderLayout.CENTER);
			f.pack();
			f.setVisible(true);
			}
			rs.close();
		}
		catch(Exception e)
		{
			JFrame J = new JFrame("������Ϣ");
			JButton but1=new JButton(" ������ѯ");
			JButton but2=new JButton("ȡ��");
			J.setLayout(null);
			JLabel L = new JLabel("��ѯ���������");
			but1.setBounds(50, 200,110,40);
	
			but2.setBounds(260, 200,110,40);
	
			L.setBounds(30, -5, 400, 200);
			J.setSize(480, 300);
			J.setLocation(520, 180);
		
			L.setFont(new Font("����",1,15));
			J.add(L);
			J.add(but1);
			J.add(but2);
			but1.addActionListener(new ActionListener(){
				public void actionPerformed(ActionEvent arg0){
					if(arg0.getSource()==but1)
					{
						J.setVisible(false);
						Change1();
					}	
				}		
			});
			but2.addActionListener(new ActionListener(){
				public void actionPerformed(ActionEvent arg0){
					if(arg0.getSource()==but2)
					{
						J.setVisible(false);
					}
				}
			});
			J.setVisible(true);
		}
	
		try
		{
			stmt.close();
			conn.close();
		}
		catch(Exception e)
		{
			System.out.println("�ر���Դ���̷����쳣��");
		}
		return Sno;
	}

	public void Change1()
	{
		
		Font f1=new Font("����",Font.BOLD,19);
		Font f2=new Font("����",Font.BOLD,16);
		
		JFrame frame =new JFrame("��ѯ��ʽѡ��");
		frame.setLayout(null);;
		JLabel ltid= new JLabel("��ʦ���");
		JLabel lname= new JLabel("��ʦ����");
		JLabel lbrithday= new JLabel("�������·�Χ");
		JLabel lbrithday2= new JLabel("��");
		JLabel lsalary= new JLabel("���ʷ�Χ");
		JLabel lsalary2= new JLabel("��");
		JLabel lworktime= new JLabel("�� �ӹ���ʱ�䷶Χ");
		JTextField ttid=new JTextField(30);
		JTextField tname=new JTextField(30);
		JTextField tbrithday=new JTextField(30);
		JTextField tbrithday2=new JTextField(30);
		JTextField tsalary=new JTextField(30);
		JTextField tsalary2=new JTextField(30);
		JTextField tworktime=new JTextField(30);
		JButton all= new JButton("ȫ����Ϣ");
		JButton confirm= new JButton("ȷ��");
		JButton ret= new JButton("����");
		
		ltid.setBounds(10, 50, 100, 30);
		lname.setBounds(10, 130, 100, 30);
		lbrithday.setBounds(10, 210, 100, 30);
		lsalary.setBounds(10, 290, 100, 30);
		lbrithday2.setBounds(230, 210, 100, 30);
		lsalary2.setBounds(230, 290, 100, 30);
		lworktime.setBounds(10, 370, 100, 30);
		
		
		ttid.setBounds(120, 50, 100, 30);
		tname.setBounds(120, 130, 100, 30);
		tbrithday.setBounds(120, 210, 100, 30);
		tsalary.setBounds(120, 290, 100, 30);
		tbrithday2.setBounds(270, 210, 100, 30);
		tsalary2.setBounds(270, 290, 100, 30);
		tworktime.setBounds(120,370, 100, 30);
		
		
		all.setBounds(10, 450, 100, 30);
		confirm.setBounds(140, 450, 100, 30);
		ret.setBounds(260, 450, 100, 30);
		
		all.addActionListener(new ActionListener(){
        	public void actionPerformed(ActionEvent arg0){
        		if(arg0.getSource()==all)
        		{
        			String sql="select * from teacher";
        			Changemember4(sql);
        			frame.setVisible(false);
        		} 
        	}
        });
		confirm.addActionListener(new ActionListener(){
        	public void actionPerformed(ActionEvent arg0){
        		if(arg0.getSource()==confirm)
        		{
        			String  false0 = "",false1 = "",false2 = "",false3 = "",false4 = "",false5 = "",false6 = "",falseZ = "";
        			if(ttid.getText().equals("")&&tname.getText().equals("")&&tbrithday.getText().equals("")&&tsalary.getText().equals("")&&tbrithday2.getText().equals("")&&tsalary2.getText().equals("")&&tworktime.getText().equals(""))
					{
        				
	        			JFrame J = new JFrame("������Ϣ");
						JButton but1=new JButton("��������");
						JButton but2=new JButton("ȡ��");
						J.setLayout(null);
						JLabel L = new JLabel("����ֵ����ȫΪ��");
						but1.setBounds(50, 200,110,40);
						but1.setFont(f2);
						but2.setBounds(260, 200,110,40);
						but2.setFont(f2);
						L.setBounds(30, -5, 400, 200);
						J.setSize(480, 300);
						J.setLocation(520, 180);
						J.setFont(f1);
						L.setFont(new Font("����",1,15));
						J.add(L);
						J.add(but1);
						J.add(but2);
						but1.addActionListener(new ActionListener(){
							public void actionPerformed(ActionEvent arg0){
								if(arg0.getSource()==but1)
								{
									J.setVisible(false);
									frame.setVisible(true);
								}	
							}		
						});
						but2.addActionListener(new ActionListener(){
							public void actionPerformed(ActionEvent arg0){
								if(arg0.getSource()==but2)
								{
									J.setVisible(false);
									frame.setVisible(false);
								}
							}
						});
						J.setVisible(true);
					}
					else
					{
						if(!ttid.getText().equals(""))
						{
							false0 = " and tid = '"+ttid.getText()+"' ";
							falseZ += false0;
						}
						if(!tname.getText().equals(""))
						{
							false1 = " and name= '"+tname.getText()+"' ";
							falseZ += false1;
						}
						if(!tbrithday.getText().equals(""))
						{
							false2 = " and brithday >= "+ Integer.parseInt(tbrithday.getText());
							falseZ += false2;
						}
						if(!tbrithday2.getText().equals(""))
						{
							false3 = " and brithday <= "+ Integer.parseInt(tbrithday2.getText());
							falseZ += false3;
						}
						if(!tsalary.getText().equals(""))
						{
							false4 = " and salary >= "+ Integer.parseInt(tsalary.getText());
							falseZ += false4;
						}	
						if(!tsalary2.getText().equals(""))
						{
							false5 = " and salary <= "+ Integer.parseInt(tsalary.getText());
							falseZ += false5;
						}
						if(!tworktime.getText().equals(""))
						{
							false6 =  " and worktime = "+ Integer.parseInt(tworktime.getText());
							falseZ += false6;
						}
						String sql="select * from teacher where inoffice='yes' "+falseZ;
	        			Changemember4(sql);
					}
        			frame.setVisible(false);
        		}
        	}
        });
		ret.addActionListener(new ActionListener(){
        	public void actionPerformed(ActionEvent arg0){
        		if(arg0.getSource()==ret)
        		{
        		
        			frame.setVisible(false);
        		} 
        	}
        });
		frame.setSize(420, 520);
		frame.setLocation(530, 130);
		frame.add(ltid);
		frame.add(lname);
		frame.add(lbrithday);
		frame.add(lsalary);
		frame.add(lbrithday2);
		frame.add(lsalary2);
		frame.add(lworktime);
		frame.add(ttid);
		frame.add(tname);
		frame.add(tbrithday);
		frame.add(tsalary);
		frame.add(tbrithday2);
		frame.add(tsalary2);
		frame.add(tworktime);
		frame.add(all);
		frame.add(confirm);
		frame.add(ret);
		frame.setVisible(true);
	}
	

	public  Change()
	{
		JFrame frame =new JFrame("�鿴ȷ��");
		frame.setLayout(null);
		JLabel Label= new JLabel("�Ƿ�Ҫ���н�ʦ��Ϣ�޸�");
		JButton but1= new JButton("��");
		JButton but2= new JButton("��");
		Font f1=new Font("����",Font.BOLD,17);
		Font f2=new Font("����",Font.BOLD,15);
		

	    but1.setBounds(40, 110,90,30);
	    but1.setFont(f2);
	    but2.setBounds(160, 110,90,30);
	    but2.setFont(f2);
		Label.setBounds(50, 5, 200,100);
		Label.setFont(f1);
		frame.setSize(320, 220);
		frame.setLocation(530, 230);
		
		but1.addActionListener(new ActionListener(){
			public void actionPerformed(ActionEvent arg0){
				if(arg0.getSource()==but1)
				{
					Change1();
					frame.setVisible(false);
				}
			}
		});
		but2.addActionListener(new ActionListener(){
			public void actionPerformed(ActionEvent arg0){
				if(arg0.getSource()==but2)
				{
					frame.setVisible(false);
				}
			}
		}); 
		frame.add(Label);
		frame.add(but1);
		frame.add(but2);
		frame.setVisible(true);
	}
}

 
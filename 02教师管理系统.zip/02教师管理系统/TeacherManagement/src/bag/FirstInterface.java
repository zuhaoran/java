package bag;

import java.awt.Color;
import java.awt.Font;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.ResultSet;
import java.sql.Statement;

import javax.swing.JButton;
import javax.swing.JFrame;
import javax.swing.JLabel;
import javax.swing.JScrollPane;
import javax.swing.JTextArea;
import javax.swing.JTextField;


public class FirstInterface
{
   public  FirstInterface()
   {
	   JFrame frame=new JFrame("��ӭʹ�ý�ʦ����ϵͳ");
	   frame.setLayout(null);
	   Font f=new Font("����",Font.BOLD,17);
	   Font f1=new Font("����",Font.BOLD,19);
		Font f2=new Font("����",Font.BOLD,16);
	   JButton e1 =new JButton("�˺Ź���");
	   JButton e2 =new JButton("ʹ��˵��");
	   JButton e3 =new JButton("������Ա");
	   JButton e4 =new JButton("�˳�");
	   JButton login =new JButton ("��¼");
	   JButton register=new JButton("ע��");
	   JLabel laccount=new JLabel("�˺�");
	   JLabel lpassword=new JLabel("����");
	   JTextField taccount=new JTextField(30);
	   JTextField tpassword= new JTextField(30);
	   
	   e1.addActionListener(new ActionListener(){
		   public void actionPerformed(ActionEvent arg0){
			   if(arg0.getSource()==e1)
			   {
				   new accountmanagement();
			   }
		   }
	   });
	   
	   e2.addActionListener(new ActionListener()
	   {
		   public void actionPerformed(ActionEvent arg0){
			   if(arg0.getSource()==e2)
			   {
				   JFrame frame =new JFrame("������Ա");
				   JTextArea jta=new JTextArea(3,20);
				   jta.setLineWrap(true);
				   @SuppressWarnings("unused")
				   JScrollPane scr= new JScrollPane(jta,
						   JScrollPane.VERTICAL_SCROLLBAR_ALWAYS,
						   JScrollPane.HORIZONTAL_SCROLLBAR_ALWAYS);
				   jta.setText("   ");
				   jta.setEnabled(false);
				   jta.setForeground(Color.black);
				   jta.setBackground(Color.black);
				   frame.add(jta);
				   
				   frame.setSize(620, 453);
				   frame.setLocation(500, 120);
				   frame.setVisible(true);
				   }
			   }
			});
	   
	   e3.addActionListener(new ActionListener()
	   {
		   public void actionPerformed(ActionEvent arg0){
			   if(arg0.getSource()==e3){
				   JFrame frame =new JFrame("������Ա");
				   JTextArea jta=new JTextArea(3,20);
				   jta.setLineWrap(true);
				   @SuppressWarnings("unused")
				JScrollPane scr= new JScrollPane(jta,
						   JScrollPane.VERTICAL_SCROLLBAR_ALWAYS,
						   JScrollPane.HORIZONTAL_SCROLLBAR_ALWAYS);
				   jta.setText("������Ա�����Ȼ  \nʹ�����ԣ�Java��sql\nʹ��������eclipse��mysql");
				   jta.setEnabled(false);
				   jta.setForeground(Color.black);
				   jta.setBackground(Color.black);
				   frame.add(jta);
				   
				   frame.setSize(620, 453);
				   frame.setLocation(500, 120);
				   frame.setVisible(true);
				   }
			   }
			});
	   
	   e4.addActionListener(new ActionListener()
	   {
		   public void actionPerformed(ActionEvent arg0){
			   if(arg0.getSource()==e4){
				   System.exit(0);
			   	}
			   }
			});
	   login.addActionListener(new ActionListener()
	   {
		   public void actionPerformed(ActionEvent arg0){
			   if(arg0.getSource()==login){
				 if(taccount.getText().equals("")||tpassword.getText().equals(""))
				 {
					    JFrame J = new JFrame("������Ϣ");
						JButton but1=new JButton("ȷ��");
						J.setLayout(null);
						JLabel L = new JLabel("�˺����벻��Ϊ��");
						but1.setBounds(50, 200,110,40);
						but1.setFont(f2);
						L.setBounds(30, -5, 400, 200);
						J.setSize(480, 300);
						J.setLocation(520, 180);
						J.setFont(f1);
						L.setFont(new Font("����",1,15));
						J.add(L);
						J.add(but1);
						J.setVisible(true);
						 but1.addActionListener(new ActionListener(){
								public void actionPerformed(ActionEvent arg0){
									if(arg0.getSource()==but1){
										J.setVisible(false);
									}
								}
							});
				 }
				 else
				 {
					String account=taccount.getText();
					String password= tpassword.getText();
					Connection conn = null;
					Statement stmt = null;
					boolean pana=false;
					boolean panp=false;
					String power=null;
					 try
						{   
							String ssql="select * from teacheraccount ";
							conn = DriverManager.getConnection("jdbc:mysql://localhost:3306/teachermanagement?user=root&password=MYSQL&characterEncoding=utf8&useSSL=true");
							stmt = conn.createStatement();
							ResultSet rs = null;
							rs = stmt.executeQuery(ssql);
							
							while(rs.next())
							{
								String saccount=rs.getString(1);
								String spassword=rs.getString(2);
								String spower=rs.getString(3);
								if(saccount.equals(account))
								{
									pana=true;
									if(spassword.equals(password))
									{
										panp=true;
										power=spower;
									}
									else
									{
										
									}
									
								}
								else
								{
								
								}
							
							}
							if(pana==true)
							{
								if(panp==true)
								{
									if(power.equals("����Ա"))
									{
									   new SecondInterface();
									   frame.setVisible(false);
								    }
									else
									{
										new SecondInterface2();
										frame.setVisible(false);
									}
								}	
								else
								{
									JFrame J2 = new JFrame("������Ϣ");
									JButton but1=new JButton("ȷ��");
									J2.setLayout(null);
									JLabel L = new JLabel("�������");
									but1.setBounds(50, 200,110,40);
									but1.setFont(f2);
									L.setBounds(30, -5, 400, 200);
									J2.setSize(480, 300);
									J2.setLocation(520, 180);
									J2.setFont(f1);
									L.setFont(new Font("����",1,15));
									J2.add(L);
									J2.add(but1);
									J2.setVisible(true);
									 but1.addActionListener(new ActionListener(){
											public void actionPerformed(ActionEvent arg0){
												if(arg0.getSource()==but1){
													J2.setVisible(false);
												}
											}
										});
								}
							}
							else 
							{
								JFrame Jaccount = new JFrame("������Ϣ");
								JButton but1=new JButton("ȷ��");
								Jaccount.setLayout(null);
								JLabel L = new JLabel("�˺Ŵ���");
								but1.setBounds(50, 200,110,40);
								but1.setFont(f2);
								L.setBounds(30, -5, 400, 200);
								Jaccount.setSize(480, 300);
								Jaccount.setLocation(520, 180);
								Jaccount.setFont(f1);
								L.setFont(new Font("����",1,15));
								Jaccount.add(L);
								Jaccount.add(but1);
								Jaccount.setVisible(true);
								 but1.addActionListener(new ActionListener(){
										public void actionPerformed(ActionEvent arg0){
											if(arg0.getSource()==but1){
												Jaccount.setVisible(false);
											}
										}
									});
							}
						}
						catch(Exception e)
						{
					
						}
				 }
			   	}
			   }
			});
	   register.addActionListener(new ActionListener()
	   {
		   public void actionPerformed(ActionEvent arg0){
			   if(arg0.getSource()==register){
				   new register();
			   	}
			   }
			});
	   
	   e1.setBounds(50, 40, 160, 50);
	   e2.setBounds(50, 160, 160, 50);//�����꣬�����꣬���ȣ�����
	   e3.setBounds(50, 280, 160, 50);
	   e4.setBounds(50, 400, 160, 50);
	   laccount.setBounds(250,80,50,30);
	   lpassword.setBounds(250,160,50,30);
	   taccount.setBounds(300, 80, 150, 30);
	   tpassword.setBounds(300, 160, 150, 30);
	   login.setBounds(280, 240, 80, 30);
	   register.setBounds(380, 240, 80, 30);
	   e1.setFont(f);
	   e2.setFont(f);
	   e3.setFont(f);
	   e4.setFont(f);
	   laccount.setFont(f);
	   frame.setSize(600, 600);
	   frame.setLocation(400, 75);
	   frame.add(e1);
	   frame.add(e2);
	   frame.add(e3);
	   frame.add(e4);
	   frame.add(laccount);
	   frame.add(taccount);
	   frame.add(lpassword);
	   frame.add(tpassword);
	   frame.add(login);
	   frame.add(register);
	   frame.setVisible(true);
	  
   }

}
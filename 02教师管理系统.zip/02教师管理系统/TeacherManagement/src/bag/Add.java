package bag;

import java.awt.BorderLayout;
import java.awt.Dimension;
import java.awt.Font;
import java.awt.GridLayout;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.Statement;

import javax.swing.ImageIcon;
import javax.swing.JButton;
import javax.swing.JFrame;
import javax.swing.JLabel;
import javax.swing.JTextField;

@SuppressWarnings("unused")
public class Add{
	public Add()
	{
	    JFrame frame=new JFrame ("����ȷ��");	    
        JLabel label=new JLabel("�Ƿ�Ҫ��������");
	    JButton but1 =new JButton("��");
	    JButton but2 =new JButton("��");
	    frame.setLayout(null);
	    
		Font f1=new Font("����",Font.BOLD,19);
		Font f2=new Font("����",Font.BOLD,16);
		
	    but1.setBounds(40, 110,90,30);
	    but1.setFont(f2);
	    but2.setBounds(160, 110,90,30);
	    but2.setFont(f2);
		label.setBounds(75, 5, 200,100);
		label.setFont(f1);
		
		frame.setSize(320, 220);
		frame.setLocation(530, 230);
	    frame.add(but1);
	    frame.add(but2);
	    frame.add(label);
	    frame.setVisible(true);	     
	    but1.addActionListener(new ActionListener(){
			public void actionPerformed(ActionEvent arg0){
				if(arg0.getSource()==but1){
					add1();
					frame.setVisible(false);
				}
			}
		});
	    but2.addActionListener(new ActionListener(){
			public void actionPerformed(ActionEvent arg0){
				if(arg0.getSource()==but2){
					frame.setVisible(false);
				}
			}
		});
	}
	
	public void add1()
	{
		Font f1=new Font("����",Font.BOLD,19);
		Font f2=new Font("����",Font.BOLD,16);
		
		JFrame frame =new JFrame("������Ҫ���ӵĽ�ʦ��Ϣ");
		JLabel t0 =new JLabel("���");
		JLabel t1 =new JLabel("����");
		JLabel t2 =new JLabel("����֤��");
		JLabel t3 =new JLabel("��ַ");
		JLabel t4 =new JLabel("�绰");
		JLabel t5 =new JLabel("����");
		JLabel t6 =new JLabel("����");
		JLabel t7 =new JLabel("�μӹ���ʱ��");
		JLabel t71 =new JLabel("��");
		JLabel t8 =new JLabel("רҵ");
		JLabel t9 =new JLabel("ְ��");
		JLabel t10 =new JLabel("��ע");
		JTextField tid=new JTextField(30);
		JTextField name=new JTextField(30);
		JTextField id=new JTextField(30);
		JTextField address=new JTextField(30);
		JTextField phone=new JTextField(30);
		JTextField department=new JTextField(50);
		JTextField salary=new JTextField(50);
		JTextField worktime=new JTextField(50);
		JTextField profess=new JTextField(50);
		JTextField duty=new JTextField(50);
		JTextField remark=new JTextField(50);
		
		JButton e1 =new JButton("ȷ��");
		JButton e2 =new JButton("ȡ��");
		frame.setLayout(null);
		t0.setBounds(100, 0, 90, 50);
		t0.setFont(f2);
		t1.setBounds(100, 50, 90, 50);
		t1.setFont(f2);
		t2.setBounds(70, 100, 90, 50);
		t2.setFont(f2);
		t3.setBounds(100, 150, 90, 50);
		t3.setFont(f2);
		t4.setBounds(100, 200, 90, 50);
		t4.setFont(f2);
		t5.setBounds(100, 250, 90, 50);
		t5.setFont(f2);
		t6.setBounds(100, 300, 90, 50);
		t6.setFont(f2);
		t7.setBounds(30, 350, 130, 50);
		t7.setFont(f2);
		t71.setBounds(400, 350, 130, 50);
		t7.setFont(f2);
		t8.setBounds(100, 400, 90, 50);
		t8.setFont(f2);
		t9.setBounds(100, 450, 90, 50);
		t9.setFont(f2);
		t10.setBounds(100, 500, 90, 50);
		t10.setFont(f2);
		tid.setBounds(150, 10, 250, 30);
		name.setBounds(150, 60, 250, 30);
		id.setBounds(150, 110, 250, 30);
		address.setBounds(150, 160, 250, 30);
		phone.setBounds(150, 210,250, 30);
		department.setBounds(150, 260, 250, 30);
		salary.setBounds(150, 310, 250, 30);
		worktime.setBounds(150, 360, 250, 30);
		profess.setBounds(150, 410, 250, 30);
		duty.setBounds(150, 460, 250, 30);
		remark.setBounds(150, 510, 250, 30);
		e1.setBounds(60, 560, 80, 30);
		e1.setFont(f2);
		e2.setBounds(300, 560,  80, 30);
		e2.setFont(f2);
		frame.add(t0);
		frame.add(tid);
		frame.add(t1);
		frame.add(name);
		frame.add(t2);
		frame.add(id);
		frame.add(t3);
		frame.add(address);
		frame.add(t4);
		frame.add(phone);
		frame.add(t5);
		frame.add(department);
		frame.add(t6);
		frame.add(salary);
		frame.add(t7);
		frame.add(t71);
		frame.add(worktime);
		
		frame.add(t8);
		frame.add(profess);
		frame.add(t9);
		frame.add(duty);
		frame.add(t10);
		frame.add(remark);
		frame.add(e1);
		frame.add(e2);
		frame.setLocation(500, 110);
		frame.setSize(500, 650);
		frame.setVisible(true);
		e1.addActionListener(new ActionListener(){
			public void actionPerformed(ActionEvent arg0){
				if(arg0.getSource()==e1)
				{
					 String  false0 = "",false1 = "",false2 = "",false3 = "",false4 = "",false5 = "",false6 = "",false7= "",false8 = "",false9 = "",falseZ = "";
					if(tid.getText().equals("")||name.getText().equals("")||id.getText().equals("")||address.getText().equals("")
					  ||phone.getText().equals("")||department.getText().equals("")||salary.getText().equals("")||worktime.getText().equals("")
					  ||profess.getText().equals("")||duty.getText().equals("")||id.getText().length()!=18)
					{
						if(tid.getText().equals(""))
						{
							false0 = "��ʦ���";
							falseZ += false0+"��";
						}
						if(name.getText().equals(""))
						{
							false1 = "����";
							falseZ += false1+"��";
						}
						if(id.getText().equals("")||id.getText().length()!=18)
						{
							false2 = "����֤��";
							falseZ += false2+"��";
						}
						if(address.getText().equals(""))
						{
							false3 = "��ַ";
							falseZ += false3+"��";
						}
						if(phone.getText().equals(""))
						{
							false4 = "�ֻ���";
							falseZ += false4+"��";
						}	
						if(department.getText().equals(""))
						{
							false5 = "����";
							falseZ += false5;
						}
						if(salary.getText().equals(""))
						{
							false6 = "����";
							falseZ += false6;
						}
						if(worktime.getText().equals(""))
						{
							false7 = "�μӹ���ʱ��";
							falseZ += false7;
						}
						if(profess.getText().equals(""))
						{
							false8 = "ְ��";
							falseZ += false8;
						}
						if(duty.getText().equals(""))
						{
							false9 = "רҵ";
							falseZ += false9;
						}
						
						
						JFrame J = new JFrame("������Ϣ");
						JButton but1=new JButton("��������");
						JButton but2=new JButton("ȡ��");
						J.setLayout(null);
						JLabel L = new JLabel(falseZ+"��������ֵ����Ϊ��");
						but1.setBounds(50, 200,110,40);
						but1.setFont(f2);
						but2.setBounds(260, 200,110,40);
						but2.setFont(f2);
						L.setBounds(30, -5, 400, 200);
						J.setSize(480, 300);
						J.setLocation(520, 180);
						J.setFont(f1);
						L.setFont(new Font("����",1,15));
						J.add(L);
						J.add(but1);
						J.add(but2);
						J.setVisible(true);
						
						but1.addActionListener(new ActionListener(){
							public void actionPerformed(ActionEvent arg0){
								if(arg0.getSource()==but1)
								{
									J.setVisible(false);
									frame.setVisible(true);
								}	
							}		
						});
						but2.addActionListener(new ActionListener(){
							public void actionPerformed(ActionEvent arg0){
								if(arg0.getSource()==but2)
								{
									J.setVisible(false);
									frame.setVisible(false);
								}
							}
						});
					}
					else
					{
						frame.setVisible(false);
						Connection conn = null;
						Statement stmt = null;
						
						try
						{
							Class.forName("con.mysql.jdbc.Driver");
						}
						catch(Exception e)
						{
							JFrame J = new JFrame();
							JLabel L = new JLabel("��������ʧ�ܡ�");
							J.add(L);
						}
						
						try
						{
							conn = DriverManager.getConnection("jdbc:mysql://localhost:3306/teachermanagement?user=root&password=MYSQL&characterEncoding=utf8&useSSL=true");
							stmt = conn.createStatement();
							String Stid = tid.getText();
							String Sname = name.getText();
							String Sid = id.getText();
							String Sbrithday=Sid.substring(7,15);
							int ibrithday=Integer.parseInt(Sbrithday);
							String saddress = address.getText();
							String sphone = phone.getText();
							String sdepartment = department.getText();
							int isalary = Integer.parseInt(salary.getText());
							String sworktime = worktime.getText();
							int iworktime=Integer.parseInt(sworktime);
							String sprofess = profess.getText();
							String sduty = duty.getText();
							String sremark="��";
							if((remark.getText().equals("")))
							{
								 sremark="��";
							}
							else
							{	
								 sremark = remark.getText();
							}
							String sql = "Insert into teacher values('"+Stid+"','"+Sname+"','"+Sid+"','"+ibrithday+"','"+saddress+"','"+sphone+"','"+sdepartment+"','"+isalary+"','"+iworktime+"','"+sprofess+"','"+sduty+"','yes','"+sremark+"')";
							int row = stmt.executeUpdate(sql);
							JFrame J = new JFrame("���ӳɹ�");
							
							JButton but1=new JButton("ȷ��");
							JButton but2=new JButton("��������");
							J.setLayout(null);
							JLabel L = new JLabel("��Ϣ��������"+row+"������");
						    but1.setBounds(30, 110,110,30);
						    but1.setFont(f2);
						    but2.setBounds(170, 110,110,30);
						    but2.setFont(f2);
							L.setBounds(55, 5, 200,100);
							L.setFont(new Font("����",1,17));
							J.setSize(320, 220);
							J.setLocation(530, 230);
							J.add(L);
							J.add(but1);
							J.add(but2);
							J.setVisible(true);
							but1.addActionListener(new ActionListener()
							{
								public void actionPerformed(ActionEvent arg0)
								{
									if(arg0.getSource()==but1)
									{
										frame.setVisible(false);
										J.setVisible(false);
									}
								}
							});
							but2.addActionListener(new ActionListener()
							{
								public void actionPerformed(ActionEvent arg0)
								{
									if(arg0.getSource()==but2)
									{
										frame.setVisible(false);
										J.setVisible(false);
										add1();
									}
								}
							});
						}
						catch(Exception e)
						{
							JFrame J = new JFrame();
							JLabel L = new JLabel("���ݿ�������̷������쳣��");
							J.add(L);
						}
						
						try
						{
							stmt.close();
							conn.close();
						}
						catch(Exception e)
						{
							JFrame J = new JFrame();
							JLabel L = new JLabel("�ر����ݿ����ӷ����쳣��");
							J.add(L);
						}
					}
				}
			}
		});
		
		
		e2.addActionListener(new ActionListener(){
			public void actionPerformed(ActionEvent arg0){
				if(arg0.getSource()==e2)
				{
					frame.setVisible(false);
				}
			}
		});
	}
}
	
package bag;

import java.awt.Font;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.ResultSet;
import java.sql.Statement;

import javax.swing.JButton;
import javax.swing.JFrame;
import javax.swing.JLabel;
import javax.swing.JTextField;

public class password {
	String mpassword=null;
	Font f1=new Font("����",Font.BOLD,19);
	Font f2=new Font("����",Font.BOLD,16);
    public password()
    {
    	
    	try
		{
		Connection conn = null;
		Statement stmt = null;
		conn = DriverManager.getConnection("jdbc:mysql://localhost:3306/teachermanagement?user=root&password=MYSQL&characterEncoding=utf8&useSSL=true");
		stmt = conn.createStatement();
		String sqlword="select * from pass";
		ResultSet rs = null;
		rs = stmt.executeQuery(sqlword);
		while(rs.next())
		{
		mpassword=rs.getString(2);
		}
		
		stmt.close();
		conn.close();
		}
		catch(Exception e)
		{
			JFrame Jf = new JFrame();
			JLabel L = new JLabel("���ݿ�������̷������쳣��");
			Jf.add(L);
		}
	    JFrame Jfr = new JFrame("�˺Ź��������ɾ��");
		JButton but1=new JButton("ȷ��");
		JButton but2=new JButton("ȡ��");
		Jfr.setLayout(null);
		JLabel L = new JLabel("�����������");
		JTextField tmpassword= new JTextField();
		but1.setBounds(50, 200,110,40);
		but1.setFont(f2);
		but2.setBounds(260, 200,110,40);
		but2.setFont(f2);
		L.setBounds(30, 80, 200, 50);
		tmpassword.setBounds(200, 80, 200, 50);
		Jfr.setSize(480, 300);
		Jfr.setLocation(520, 180);
		Jfr.setFont(f1);
		L.setFont(new Font("����",1,15));
		Jfr.add(L);
		Jfr.add(tmpassword);
		Jfr.add(but1);
		Jfr.add(but2);
		but1.addActionListener(new ActionListener(){
			public void actionPerformed(ActionEvent arg0){
				if(arg0.getSource()==but1)
				{
					String password=tmpassword.getText();
					if(password.equals(mpassword))
					{
						updata();
						Jfr.setVisible(false); 
					}
					else
					{
						JFrame J = new JFrame("����");
						JButton but1=new JButton("ȷ��");
						J.setLayout(null);
						JLabel L = new JLabel("�����������");
						but1.setBounds(30, 110,110,30);
						but1.setFont(f2);
						L.setBounds(55, 5, 200,100);
						L.setFont(new Font("����",1,17));
						J.setSize(320, 220);
						J.setLocation(530, 230);
						J.add(L);
						J.add(but1);
						J.setVisible(true);
						but1.addActionListener(new ActionListener()
						{
							public void actionPerformed(ActionEvent arg0)
							{
								if(arg0.getSource()==but1)
								{
									J.setVisible(false);
								}
							}
						});
					}
				}	
			}		
		});
		but2.addActionListener(new ActionListener(){
			public void actionPerformed(ActionEvent arg0){
				if(arg0.getSource()==but2)
				{
					Jfr.setVisible(false);
				}
			}
		});
		Jfr.setVisible(true);
    }
    void updata()
    {
    	JFrame Jfr = new JFrame("�˺Ź��������ɾ��");
		JButton but1=new JButton("ȷ��");
		JButton but2=new JButton("ȡ��");
		Jfr.setLayout(null);
		JLabel L = new JLabel("�����������");
		JTextField tmpassword= new JTextField();
		JLabel L2 = new JLabel("�ٴ���������");
		JTextField tmpassword2= new JTextField();
		but1.setBounds(50, 200,110,40);
		but1.setFont(f2);
		but2.setBounds(260, 200,110,40);
		but2.setFont(f2);
		L.setBounds(30, 20, 200, 40);
		tmpassword.setBounds(200, 20, 200, 40);
		L2.setBounds(30, 70, 200, 40);
		tmpassword2.setBounds(200, 70, 200, 40);
		Jfr.setSize(480, 300);
		Jfr.setLocation(520, 180);
		Jfr.setFont(f1);
		L.setFont(new Font("����",1,15));
		L2.setFont(new Font("����",1,15));
		Jfr.add(L);
		Jfr.add(tmpassword);
		Jfr.add(L2);
		Jfr.add(tmpassword2);
		Jfr.add(but1);
		Jfr.add(but2);
    	
    	but1.addActionListener(new ActionListener(){
			public void actionPerformed(ActionEvent arg0){
				if(arg0.getSource()==but1)
				{
					String password1=tmpassword.getText();
					String password2=tmpassword2.getText();
					if(password1==""||password2==""||password1.equals("")||password2.equals(""))
					{
						JFrame J = new JFrame("����");
						JButton but1=new JButton("ȷ��");
						J.setLayout(null);
						JLabel L = new JLabel("����Ϊ��");
						but1.setBounds(30, 110,110,30);
						but1.setFont(f2);
						L.setBounds(55, 5, 200,100);
						L.setFont(new Font("����",1,17));
						J.setSize(320, 220);
						J.setLocation(530, 230);
						J.add(L);
						J.add(but1);
						J.setVisible(true);
						but1.addActionListener(new ActionListener()
						{
							public void actionPerformed(ActionEvent arg0)
							{
								if(arg0.getSource()==but1)
								{
									J.setVisible(false);
								}
							}
						});
					}
					else{
					if(password1.equals(password2))
					{
						
						try
						{
						String sql = "update pass set password = '"+password1+"' where id = 1";
						Connection conn = null;
						Statement stmt = null;
						conn = DriverManager.getConnection("jdbc:mysql://localhost:3306/teachermanagement?user=root&password=MYSQL&characterEncoding=utf8&useSSL=true");
						stmt = conn.createStatement();
						int row = stmt.executeUpdate(sql);
						Jfr.setVisible(false);
						JFrame J = new JFrame("���ĳɹ�");
						JButton maketrue=new JButton("ȷ��");
						J.setLayout(null);
						JLabel La = new JLabel("����������");
						maketrue.setBounds(30, 110,110,30);
						maketrue.setFont(f2);
						La.setBounds(55, 5, 200,100);
						La.setFont(new Font("����",1,17));
						J.setSize(320, 220);
						J.setLocation(530, 230);
						J.add(La);
						J.add(maketrue);
						J.setVisible(true);
						maketrue.addActionListener(new ActionListener()
						{
							public void actionPerformed(ActionEvent arg0)
							{
								if(arg0.getSource()==maketrue)
								{
									J.setVisible(false);
								}
							}
						});
						
						stmt.close();
						conn.close();
						}
						catch(Exception e)
						{
							JFrame J = new JFrame();
							JLabel La = new JLabel("���ݿ�������̷������쳣��");
							J.add(La);
						}
					}
					else
					{
						JFrame J = new JFrame("����");
						JButton but1=new JButton("ȷ��");
						J.setLayout(null);
						JLabel L = new JLabel("���벻һ��");
						but1.setBounds(30, 110,110,30);
						but1.setFont(f2);
						L.setBounds(55, 5, 200,100);
						L.setFont(new Font("����",1,17));
						J.setSize(320, 220);
						J.setLocation(530, 230);
						J.add(L);
						J.add(but1);
						J.setVisible(true);
						but1.addActionListener(new ActionListener()
						{
							public void actionPerformed(ActionEvent arg0)
							{
								if(arg0.getSource()==but1)
								{
									J.setVisible(false);
								}
							}
						});
					}
					}
					
				}
			}
		});
    	but2.addActionListener(new ActionListener(){
			public void actionPerformed(ActionEvent arg0){
				if(arg0.getSource()==but2)
				{
					Jfr.setVisible(false);
				}
			}
		});
    	
		Jfr.setVisible(true);
    }
    
}

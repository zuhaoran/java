package bag;

import java.awt.BorderLayout;
import java.awt.Dimension;
import java.awt.Font;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.awt.event.MouseAdapter;
import java.awt.event.MouseEvent;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.ResultSet;
import java.sql.Statement;

import javax.swing.JButton;
import javax.swing.JFrame;
import javax.swing.JLabel;
import javax.swing.JScrollPane;
import javax.swing.JTable;
import javax.swing.JTextField;

public class accountmanagement {
	
	
	String mpassword=null;
	Font f1=new Font("����",Font.BOLD,19);
	Font f2=new Font("����",Font.BOLD,16);
	accountmanagement()
	{
		try
		{
		String sqla = null;
		Connection conn = null;
		Statement stmt = null;
		conn = DriverManager.getConnection("jdbc:mysql://localhost:3306/teachermanagement?user=root&password=MYSQL&characterEncoding=utf8&useSSL=true");
		stmt = conn.createStatement();
		
		
		String sqlword="select * from pass";
		ResultSet rs = null;
		rs = stmt.executeQuery(sqlword);
		while(rs.next())
		{
		mpassword=rs.getString(2);
		}
		
		stmt.close();
		conn.close();
		}
		catch(Exception e)
		{
			JFrame J = new JFrame();
			JLabel L = new JLabel("���ݿ�������̷������쳣��");
			J.add(L);
		}
	    JFrame J = new JFrame("�˺Ź��������ɾ��");
		JButton but1=new JButton("ȷ��");
		JButton but2=new JButton("ȡ��");
		J.setLayout(null);
		JLabel L = new JLabel("�����������");
		JTextField tmpassword= new JTextField();
		but1.setBounds(50, 200,110,40);
		but1.setFont(f2);
		but2.setBounds(260, 200,110,40);
		but2.setFont(f2);
		L.setBounds(30, 80, 200, 50);
		tmpassword.setBounds(200, 80, 200, 50);
		J.setSize(480, 300);
		J.setLocation(520, 180);
		J.setFont(f1);
		L.setFont(new Font("����",1,15));
		J.add(L);
		J.add(tmpassword);
		J.add(but1);
		J.add(but2);
		but1.addActionListener(new ActionListener(){
			public void actionPerformed(ActionEvent arg0){
				if(arg0.getSource()==but1)
				{
					String password=tmpassword.getText();
					if(password.equals(mpassword))
					{
						String Sql="select * from teacheraccount";
						String Sqldelete=null;
						Checkmember4(Sql);
						J.setVisible(false); 
					}
					else
					{
						JFrame J = new JFrame("����");
						JButton but1=new JButton("ȷ��");
						J.setLayout(null);
						JLabel L = new JLabel("�����������");
						but1.setBounds(30, 110,110,30);
						but1.setFont(f2);
						L.setBounds(55, 5, 200,100);
						L.setFont(new Font("����",1,17));
						J.setSize(320, 220);
						J.setLocation(530, 230);
						J.add(L);
						J.add(but1);
						J.setVisible(true);
						but1.addActionListener(new ActionListener()
						{
							public void actionPerformed(ActionEvent arg0)
							{
								if(arg0.getSource()==but1)
								{
									J.setVisible(false);
								}
							}
						});
					}
				}	
			}		
		});
		but2.addActionListener(new ActionListener(){
			public void actionPerformed(ActionEvent arg0){
				if(arg0.getSource()==but2)
				{
					J.setVisible(false);
				}
			}
		});
		J.setVisible(true);
	}
	public String[] Checkmember4(String sql)
	{
		
		Connection conn = null;
		Statement stmt = null;
		String Sno[] = null;
		
		try
		{
			Class.forName("com.mysql.jdbc.Driver");
		}
		catch(Exception e)
		{
			System.out.println("��������ʧ�ܡ�");
		}
	
		try
		{
			conn = DriverManager.getConnection("jdbc:mysql://localhost:3306/teachermanagement?user=root&password=MYSQL&characterEncoding=utf8&useSSL=true");
			stmt = conn.createStatement();
			
			int count = 0;
			String[] a1=new String[100];
			String[] a2=new String[100];
			String[] a3=new String[100];
			ResultSet rs = null;
			rs = stmt.executeQuery(sql);
			for(int i = 0;i < 100;i++)
			{
				a1[i] = "0";
				a2[i] = "0";
				a3[i] = "0";
			}
				
			while(rs.next())
			{
				String saccount=rs.getString(1);
				String spassword=rs.getString(2);
				String  spower= rs.getString(3);
				for(int i = 0;i < 100;i++)
				{
					if(a1[i]== saccount)
					{
						break;
					}
					else if(a3[i] != "0")
					{
						continue;
					}
					else
					{
						a1[i] = saccount;
						a2[i] =spassword;
						a3[i] =spower;
						break;
					}
				}
			}
				
			
				
			count = 0;
			for(int i = 0;i < 100;i++)
			{
				if(a3[i] != "0")
				{
					count++;
				}
				else
				{
					break;
				}
			}
			count++;
			
			String Snum[] = new String [count];
                 
			for(int i = 0;i < count;i++)
			{
				Snum[i] = a3[i];
			}
			
			String[][] b =new String[count][11];
			for(int i=0;i<count-1;i++)
			{
			  b[i][0]=a1[i];
			  b[i][1]=a2[i];
			  b[i][2]=a3[i];
			}
			Object[][] playerInfo = b;
			String[] Names={"�˺�","����","����"};
			JFrame f=new JFrame("��ѯ���");
			f.setBounds(470, 100, 600, 400);
			JTable table=new JTable(playerInfo,Names);
		    table.setPreferredScrollableViewportSize(new Dimension(600,400));
			JScrollPane scrollPane=new JScrollPane(table);
			table.addMouseListener(new MouseAdapter(){
				public void mouseClicked(MouseEvent e){   
					if(e.getClickCount() == 1)
			    	{
						int row =((JTable)e.getSource()).rowAtPoint(e.getPoint()); //�����λ�� 
						String saccount=(String)(table.getValueAt(row,0));  
					    f.setVisible(false);
					    String sqldelete2="delete from teacheraccount where account='"+saccount+"'";
					    System.out.println(sqldelete2);
					    Deletemember5(sqldelete2);
						Checkmember4(sql);
			    	}
					else return;
				}
			});
			table.addMouseListener(new MouseAdapter(){
				public void mouseClicked(MouseEvent e){   
					if(e.getClickCount() == 1)
			    	{
					    f.setVisible(false);
			    	}
					else return;
				}
			});
			
			
			f.getContentPane().add(scrollPane,BorderLayout.CENTER);
			f.pack();
			f.setVisible(true);
			rs.close();
		}
		catch(Exception e)
		{
			JFrame J = new JFrame("������Ϣ");
			JButton but1=new JButton(" ������ѯ");
			JButton but2=new JButton("ȡ��");
			J.setLayout(null);
			JLabel L = new JLabel("��ѯ���������");
			but1.setBounds(50, 200,110,40);
	
			but2.setBounds(260, 200,110,40);
	
			L.setBounds(30, -5, 400, 200);
			J.setSize(480, 300);
			J.setLocation(520, 180);
		
			L.setFont(new Font("����",1,15));
			J.add(L);
			J.add(but1);
			J.add(but2);
			but1.addActionListener(new ActionListener(){
				public void actionPerformed(ActionEvent arg0){
					if(arg0.getSource()==but1)
					{
						J.setVisible(false);
					}	
				}		
			});
			but2.addActionListener(new ActionListener(){
				public void actionPerformed(ActionEvent arg0){
					if(arg0.getSource()==but2)
					{
						J.setVisible(false);
					}
				}
			});
			J.setVisible(true);
		}
	
		try
		{
			stmt.close();
			conn.close();
		}
		catch(Exception e)
		{
			System.out.println("�ر���Դ���̷����쳣��");
		}
		return Sno;
	}

	public String[] Deletemember5(String sql)
	{
		Connection conn = null;
		Statement stmt = null;
		String Sno[] = null;
		
		try
		{
			Class.forName("com.mysql.jdbc.Driver");
		}
		catch(Exception e)
		{
			System.out.println("��������ʧ�ܡ�");
		}
	
		try
		{
			conn = DriverManager.getConnection("jdbc:mysql://localhost:3306/teachermanagement?user=root&password=MYSQL&characterEncoding=utf8&useSSL=true");
			stmt = conn.createStatement();
		
			int row= stmt.executeUpdate(sql);	
			System.out.println(row);
		}
		catch(Exception e)
		{
			System.out.println("���ݿ���������쳣��");
		}
	
		try
		{
			stmt.close();
			conn.close();
		}
		catch(Exception e)
		{
			System.out.println("�ر���Դ���̷����쳣��");
		}
		return Sno;
	}
	

}
/*int row = stmt.executeUpdate(sqla);
JFrame J = new JFrame("���ĳɹ�");
JButton but1=new JButton("ȷ��");
J.setLayout(null);
JLabel L = new JLabel("��Ϣ��������"+row+"������");
but1.setBounds(30, 110,110,30);
but1.setFont(f2);
L.setBounds(55, 5, 200,100);
L.setFont(new Font("����",1,17));
J.setSize(320, 220);
J.setLocation(530, 230);
J.add(L);
J.add(but1);
J.setVisible(true);
but1.addActionListener(new ActionListener()
{
	public void actionPerformed(ActionEvent arg0)
	{
		if(arg0.getSource()==but1)
		{
			J.setVisible(false);
		}
	}
});*/